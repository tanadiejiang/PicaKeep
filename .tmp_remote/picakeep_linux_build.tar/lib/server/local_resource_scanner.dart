import 'dart:convert';
import 'dart:io';

import 'package:sqlite3/sqlite3.dart';
import 'package:picakeep/foundation/download_model.dart';

const _serverTrashDirectoryName = '.picakeep_trash';

class ServerResourceRootSummary {
  const ServerResourceRootSummary({
    required this.id,
    required this.title,
    required this.path,
    required this.exists,
    required this.itemCount,
    required this.totalBytes,
  });

  final String id;
  final String title;
  final String path;
  final bool exists;
  final int itemCount;
  final int totalBytes;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'path': path,
        'exists': exists,
        'itemCount': itemCount,
        'totalBytes': totalBytes,
      };
}

class ServerResourceImageSize {
  const ServerResourceImageSize({
    required this.width,
    required this.height,
  });

  final int width;
  final int height;

  Map<String, dynamic> toJson() => {
        'width': width,
        'height': height,
      };
}

class ServerResourceEpisodeSummary {
  const ServerResourceEpisodeSummary({
    required this.index,
    required this.title,
    required this.path,
    required this.imageCount,
    required this.totalBytes,
    required this.coverPath,
    required this.imagePaths,
    required this.imageSizes,
  });

  final int index;
  final String title;
  final String path;
  final int imageCount;
  final int totalBytes;
  final String? coverPath;
  final List<String> imagePaths;
  final List<ServerResourceImageSize?> imageSizes;

  Map<String, dynamic> toJson() => {
        'index': index,
        'title': title,
        'path': path,
        'imageCount': imageCount,
        'totalBytes': totalBytes,
        'coverPath': coverPath,
      };
}

class _ServerResourceMetadata {
  const _ServerResourceMetadata({
    required this.title,
    required this.subtitle,
    required this.displayId,
    required this.tags,
    required this.coverPath,
    required this.sourceDisplayName,
    required this.episodeTitles,
    required this.updatedAt,
  });

  final String title;
  final String subtitle;
  final String displayId;
  final List<String> tags;
  final String coverPath;
  final String sourceDisplayName;
  final List<String> episodeTitles;
  final DateTime? updatedAt;
}

class ServerResourceItemSummary {
  const ServerResourceItemSummary({
    required this.id,
    required this.rootId,
    required this.sourceTitle,
    required this.sourceDisplayName,
    required this.title,
    required this.displayId,
    required this.subtitle,
    required this.tags,
    required this.path,
    required this.imageCount,
    required this.totalBytes,
    required this.coverPath,
    required this.episodes,
    required this.updatedAt,
  });

  final String id;
  final String rootId;
  final String sourceTitle;
  final String sourceDisplayName;
  final String title;
  final String displayId;
  final String subtitle;
  final List<String> tags;
  final String path;
  final int imageCount;
  final int totalBytes;
  final String? coverPath;
  final List<ServerResourceEpisodeSummary> episodes;
  final DateTime updatedAt;

  bool get hasMultipleEpisodes => episodes.length > 1;

  Map<String, dynamic> toJson() => {
        'id': id,
        'rootId': rootId,
        'sourceTitle': sourceTitle,
        'sourceDisplayName': sourceDisplayName,
        'title': title,
        'displayId': displayId,
        'subtitle': subtitle,
        'tags': tags,
        'path': path,
        'imageCount': imageCount,
        'totalBytes': totalBytes,
        'coverPath': coverPath,
        'updatedAt': updatedAt.toIso8601String(),
        'episodeCount': episodes.length,
        'hasMultipleEpisodes': hasMultipleEpisodes,
        'episodes': episodes.map((e) => e.toJson()).toList(),
      };
}

class ServerResourceSnapshot {
  const ServerResourceSnapshot({
    required this.generatedAt,
    required this.totalComicCount,
    required this.totalBytes,
    required this.roots,
    required this.items,
  });

  final DateTime generatedAt;
  final int totalComicCount;
  final int totalBytes;
  final List<ServerResourceRootSummary> roots;
  final List<ServerResourceItemSummary> items;

  ServerResourceItemSummary? findItemById(String id) {
    final normalizedId = id.trim();
    if (normalizedId.isEmpty) {
      return null;
    }
    for (final item in items) {
      if (item.id == normalizedId) {
        return item;
      }
    }
    return null;
  }

  Map<String, dynamic> toJson() => {
        'generatedAt': generatedAt.toIso8601String(),
        'totalComicCount': totalComicCount,
        'totalBytes': totalBytes,
        'roots': roots.map((e) => e.toJson()).toList(),
        'items': items.map((e) => e.toJson()).toList(),
      };
}

class LocalResourceScanner {
  Future<ServerResourceSnapshot> scan({
    required String currentDownloadRoot,
    required String originalDownloadRoot,
    required List<String> customLibraryRoots,
  }) async {
    final roots = <ServerResourceRootSummary>[];
    final items = <ServerResourceItemSummary>[];

    final allRoots = <({String id, String title, String path})>[
      (
        id: 'current_download',
        title: '本应用下载目录',
        path: currentDownloadRoot.trim(),
      ),
      (
        id: 'original_download',
        title: '原应用下载目录',
        path: originalDownloadRoot.trim(),
      ),
      for (var i = 0; i < customLibraryRoots.length; i++)
        (
          id: 'custom_$i',
          title: '自定义路径 ${i + 1}',
          path: customLibraryRoots[i].trim(),
        ),
    ].where((e) => e.path.isNotEmpty).toList();

    for (final root in allRoots) {
      final directory = Directory(root.path);
      if (!await directory.exists()) {
        roots.add(
          ServerResourceRootSummary(
            id: root.id,
            title: root.title,
            path: root.path,
            exists: false,
            itemCount: 0,
            totalBytes: 0,
          ),
        );
        continue;
      }

      final discoveredItems = await _scanRootItems(root.id, root.title, directory);
      final totalBytes = discoveredItems.fold<int>(
        0,
        (sum, item) => sum + item.totalBytes,
      );
      roots.add(
        ServerResourceRootSummary(
          id: root.id,
          title: root.title,
          path: root.path,
          exists: true,
          itemCount: discoveredItems.length,
          totalBytes: totalBytes,
        ),
      );
      items.addAll(discoveredItems);
    }

    return ServerResourceSnapshot(
      generatedAt: DateTime.now(),
      totalComicCount: items.length,
      totalBytes: items.fold<int>(0, (sum, item) => sum + item.totalBytes),
      roots: roots,
      items: items,
    );
  }

  Future<List<ServerResourceItemSummary>> _scanRootItems(
    String rootId,
    String rootTitle,
    Directory root,
  ) async {
    if (rootId.startsWith('custom_')) {
      return _scanCustomRootItems(rootId, rootTitle, root);
    }

    final metadataByDirectory = _loadManagedRootMetadata(rootTitle, root);
    final results = <ServerResourceItemSummary>[];
    final children = await _listDirectories(root);
    for (final child in children) {
      final item = await _scanComicItem(
        rootId,
        rootTitle,
        root.path,
        child,
        metadataByDirectory,
      );
      if (item != null) {
        results.add(item);
      }
    }
    if (results.isNotEmpty) {
      return results;
    }

    final rootItem = await _scanComicItem(
      rootId,
      rootTitle,
      root.path,
      root,
      metadataByDirectory,
    );
    if (rootItem != null) {
      results.add(rootItem);
    }
    return results;
  }

  Future<List<ServerResourceItemSummary>> _scanCustomRootItems(
    String rootId,
    String rootTitle,
    Directory root,
  ) async {
    final results = <ServerResourceItemSummary>[];
    final directories = _collectLeafAlbumDirectories(root);
    for (final directory in directories) {
      final images = _listDirectVisibleImages(directory);
      final episode = await _buildEpisodeSummary(
        index: 1,
        title: _directoryTitle(directory),
        directory: directory,
        images: images,
      );
      if (episode == null) {
        continue;
      }
      results.add(
        ServerResourceItemSummary(
          id: _buildItemId(rootId, directory.path),
          rootId: rootId,
          sourceTitle: rootTitle,
          sourceDisplayName: '图集',
          title: _directoryTitle(directory),
          displayId: _directoryTitle(directory),
          subtitle: '${episode.imageCount} 张图片',
          tags: const <String>[],
          path: directory.path,
          imageCount: episode.imageCount,
          totalBytes: episode.totalBytes,
          coverPath: episode.coverPath,
          episodes: [episode],
          updatedAt: await _directoryUpdatedAt(directory),
        ),
      );
    }
    return results;
  }

  Future<ServerResourceItemSummary?> _scanComicItem(
    String rootId,
    String rootTitle,
    String rootPath,
    Directory directory,
    Map<String, _ServerResourceMetadata> metadataByDirectory,
  ) async {
    final directImages = await _listImageFiles(directory, recursive: false);
    final episodes = <ServerResourceEpisodeSummary>[];

    if (directImages.isNotEmpty) {
      final images = await _listImageFiles(directory, recursive: true);
      final episode = await _buildEpisodeSummary(
        index: 1,
        title: _directoryTitle(directory),
        directory: directory,
        images: images,
      );
      if (episode != null) {
        episodes.add(episode);
      }
    } else {
      final children = await _listDirectories(directory);
      for (final child in children) {
        final images = await _listImageFiles(child, recursive: true);
        final episode = await _buildEpisodeSummary(
          index: episodes.length + 1,
          title: _directoryTitle(child),
          directory: child,
          images: images,
        );
        if (episode != null) {
          episodes.add(episode);
        }
      }

      if (episodes.isEmpty) {
        final images = await _listImageFiles(directory, recursive: true);
        final episode = await _buildEpisodeSummary(
          index: 1,
          title: _directoryTitle(directory),
          directory: directory,
          images: images,
        );
        if (episode != null) {
          episodes.add(episode);
        }
      }
    }

    if (episodes.isEmpty) {
      return null;
    }

    final imageCount = episodes.fold<int>(0, (sum, item) => sum + item.imageCount);
    final totalBytes = episodes.fold<int>(0, (sum, item) => sum + item.totalBytes);
    final metadata = _resolveManagedMetadata(
      metadataByDirectory,
      rootPath,
      directory.path,
    );
    final titledEpisodes = _applyEpisodeTitles(
      episodes,
      metadata?.episodeTitles ?? const <String>[],
    );
    final fallbackSubtitle = titledEpisodes.length > 1
        ? '${titledEpisodes.length} 个章节'
        : '$imageCount 张图片';
    final subtitle = _firstNonEmptyValue([
      metadata?.subtitle,
      fallbackSubtitle,
    ]);
    final sourceDisplayName = _firstNonEmptyValue([
      metadata?.sourceDisplayName,
      rootTitle,
    ]);
    final title = _firstNonEmptyValue([
      metadata?.title,
      _directoryTitle(directory),
    ]);
    final displayId = _firstNonEmptyValue([
      metadata?.displayId,
      _buildItemId(rootId, directory.path),
    ]);
    final updatedAt = metadata?.updatedAt ?? await _directoryUpdatedAt(directory);
    return ServerResourceItemSummary(
      id: _buildItemId(rootId, directory.path),
      rootId: rootId,
      sourceTitle: rootTitle,
      sourceDisplayName: sourceDisplayName,
      title: title,
      displayId: displayId,
      subtitle: subtitle,
      tags: metadata?.tags ?? const <String>[],
      path: directory.path,
      imageCount: imageCount,
      totalBytes: totalBytes,
      coverPath: _resolveItemCoverPath(
        metadata?.coverPath,
        directory,
        titledEpisodes,
      ),
      episodes: titledEpisodes,
      updatedAt: updatedAt,
    );
  }

  Map<String, _ServerResourceMetadata> _loadManagedRootMetadata(
    String rootTitle,
    Directory root,
  ) {
    final dbFile = File('${root.path}${Platform.pathSeparator}download.db');
    if (!dbFile.existsSync()) {
      return const <String, _ServerResourceMetadata>{};
    }

    Database? db;
    final results = <String, _ServerResourceMetadata>{};
    try {
      db = sqlite3.open(dbFile.path);
      final rows = db.select(
        'select id, title, subtitle, time, directory, json from download',
      );
      for (final row in rows) {
        final rawId = row['id']?.toString() ?? '';
        final rawDirectory = row['directory']?.toString() ?? '';
        final rawJson = row['json']?.toString() ?? '';
        final rawTime = (row['time'] as num?)?.toInt();
        final itemTime = rawTime == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(rawTime);
        final data = _decodeJsonMap(rawJson);
        final parsedItem = parseDownloadedItemRecordJson(
          rawId,
          rawJson,
          time: itemTime,
          directory: rawDirectory,
        );
        final metadata = _extractDownloadMetadata(
          id: rawId,
          title: row['title']?.toString() ?? '',
          subtitle: row['subtitle']?.toString() ?? '',
          updatedAt: itemTime,
          data: data,
          parsedItem: parsedItem,
          fallbackSourceDisplayName: rootTitle,
        );
        final lookupKeys = _metadataLookupKeysForStoredRecord(
          root.path,
          rawId,
          rawDirectory,
        );
        if (lookupKeys.isEmpty) {
          continue;
        }
        for (final key in lookupKeys) {
          if (key.contains('/') || key.startsWith('id::')) {
            results[key] = metadata;
          } else {
            results.putIfAbsent(key, () => metadata);
          }
        }
      }
    } catch (_) {
      return const <String, _ServerResourceMetadata>{};
    } finally {
      db?.dispose();
    }
    return results;
  }

  _ServerResourceMetadata _extractDownloadMetadata({
    required String id,
    required String title,
    required String subtitle,
    required DateTime? updatedAt,
    required Map<String, dynamic>? data,
    required DownloadedItem? parsedItem,
    required String fallbackSourceDisplayName,
  }) {
    final comicItem = data?['comicItem'];
    final comicItemMap = comicItem is Map
        ? comicItem.map((key, value) => MapEntry(key.toString(), value))
        : null;
    final parsedJson = parsedItem?.toJson();
    final parsedTags = parsedItem?.tags
            .map((entry) => entry.trim())
            .where((entry) => entry.isNotEmpty)
            .toList(growable: false) ??
        const <String>[];
    final parsedEpisodeTitles = _parsedEpisodeTitles(parsedItem);
    return _ServerResourceMetadata(
      title: _firstNonEmptyValue([
        parsedItem?.name,
        title,
        data?['title']?.toString(),
        comicItemMap?['title']?.toString(),
      ]),
      subtitle: _firstNonEmptyValue([
        parsedItem?.subTitle,
        subtitle,
        data?['subtitle']?.toString(),
        data?['subTitle']?.toString(),
        data?['author']?.toString(),
        comicItemMap?['subTitle']?.toString(),
        comicItemMap?['author']?.toString(),
      ]),
      displayId: _firstNonEmptyValue([
        data?['displayId']?.toString(),
        data?['comicId']?.toString(),
        parsedJson?['displayId']?.toString(),
        parsedJson?['comicId']?.toString(),
        parsedJson?['comicID']?.toString(),
        comicItemMap?['displayId']?.toString(),
        comicItemMap?['comicId']?.toString(),
        comicItemMap?['id']?.toString(),
        parsedItem?.id,
        id,
      ]),
      tags: parsedTags.isNotEmpty
          ? parsedTags
          : _extractTagValues(data, comicItemMap),
      coverPath: _extractCoverPath(data, comicItemMap, parsedItem),
      sourceDisplayName: _firstNonEmptyValue([
        data?['sourceDisplayName']?.toString(),
        parsedItem?.sourceDisplayName,
        _inferSourceDisplayName(id, data),
        fallbackSourceDisplayName,
      ]),
      episodeTitles: parsedEpisodeTitles.isNotEmpty
          ? parsedEpisodeTitles
          : _extractEpisodeTitles(data, comicItemMap),
      updatedAt: updatedAt,
    );
  }

  String _normalizeManagedDirectoryPath(String rootPath, String directory) {
    final normalizedDirectory = directory.trim();
    if (normalizedDirectory.isEmpty) {
      return '';
    }

    final unifiedDirectory = normalizedDirectory.replaceAll('\\', '/');
    final isAbsolute = unifiedDirectory.startsWith('/') ||
        RegExp(r'^[a-zA-Z]:/').hasMatch(unifiedDirectory);
    if (isAbsolute) {
      return _normalizePath(unifiedDirectory);
    }

    final normalizedRoot = rootPath.trim().replaceAll('\\', '/');
    if (normalizedRoot.isEmpty) {
      return _normalizePath(unifiedDirectory);
    }
    final joinedRoot = normalizedRoot.endsWith('/')
        ? normalizedRoot.substring(0, normalizedRoot.length - 1)
        : normalizedRoot;
    return _normalizePath('$joinedRoot/$unifiedDirectory');
  }

  String _relativeManagedDirectoryPath(String rootPath, String directoryPath) {
    final normalizedRoot = _normalizePath(rootPath);
    final normalizedDirectory = _normalizePath(directoryPath);
    if (normalizedRoot.isEmpty || normalizedDirectory.isEmpty) {
      return '';
    }
    if (normalizedDirectory == normalizedRoot) {
      return '';
    }
    final prefix = '$normalizedRoot/';
    if (!normalizedDirectory.startsWith(prefix)) {
      return '';
    }
    return normalizedDirectory.substring(prefix.length);
  }

  List<String> _metadataLookupKeysForStoredRecord(
    String rootPath,
    String rawId,
    String rawDirectory,
  ) {
    final keys = <String>[];

    void add(String value) {
      final normalized = value.trim();
      if (normalized.isEmpty || keys.contains(normalized)) {
        return;
      }
      keys.add(normalized);
    }

    final normalizedDirectoryPath =
        _normalizeManagedDirectoryPath(rootPath, rawDirectory);
    final relativeDirectoryPath =
        _relativeManagedDirectoryPath(rootPath, normalizedDirectoryPath);

    add('id::${rawId.trim()}');
    add(normalizedDirectoryPath);
    add(relativeDirectoryPath);
    add(_normalizePath(rawDirectory));
    add(_normalizePath(_basename(rawDirectory)));
    add(_normalizePath(_basename(normalizedDirectoryPath)));
    add(_normalizePath(_basename(relativeDirectoryPath)));
    return keys;
  }

  List<String> _metadataLookupKeysForResolvedDirectory(
    String rootPath,
    String directoryPath,
  ) {
    final keys = <String>[];

    void add(String value) {
      final normalized = value.trim();
      if (normalized.isEmpty || keys.contains(normalized)) {
        return;
      }
      keys.add(normalized);
    }

    final normalizedDirectoryPath = _normalizePath(directoryPath);
    final relativeDirectoryPath =
        _relativeManagedDirectoryPath(rootPath, normalizedDirectoryPath);

    add(normalizedDirectoryPath);
    add(relativeDirectoryPath);
    add(_normalizePath(_basename(directoryPath)));
    add(_normalizePath(_basename(normalizedDirectoryPath)));
    add(_normalizePath(_basename(relativeDirectoryPath)));
    return keys;
  }

  _ServerResourceMetadata? _resolveManagedMetadata(
    Map<String, _ServerResourceMetadata> metadataByDirectory,
    String rootPath,
    String directoryPath,
  ) {
    for (final key in _metadataLookupKeysForResolvedDirectory(
      rootPath,
      directoryPath,
    )) {
      final metadata = metadataByDirectory[key];
      if (metadata != null) {
        return metadata;
      }
    }
    return null;
  }

  Map<String, dynamic>? _decodeJsonMap(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return null;
    }
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map) {
        return decoded.map((key, value) => MapEntry(key.toString(), value));
      }
    } catch (_) {}
    return null;
  }

  List<String> _parsedEpisodeTitles(DownloadedItem? parsedItem) {
    if (parsedItem == null) {
      return const <String>[];
    }
    final titles = parsedItem.eps
        .map((entry) => entry.trim())
        .where((entry) => entry.isNotEmpty)
        .toList(growable: false);
    if (titles.isEmpty) {
      return const <String>[];
    }
    if (titles.length == 1 && titles.first == parsedItem.name.trim()) {
      return const <String>[];
    }
    return titles;
  }

  Iterable<Map<String, dynamic>> _candidateMetadataMaps(
    Map<String, dynamic>? data,
    Map<String, dynamic>? comicItemMap,
  ) sync* {
    for (final map in [
      data,
      comicItemMap,
      _asStringDynamicMap(data?['comic']),
      _asStringDynamicMap(data?['gallery']),
      _asStringDynamicMap(data?['metadata']),
      _asStringDynamicMap(data?['detail']),
      _asStringDynamicMap(comicItemMap?['comic']),
      _asStringDynamicMap(comicItemMap?['gallery']),
      _asStringDynamicMap(comicItemMap?['metadata']),
      _asStringDynamicMap(comicItemMap?['detail']),
    ]) {
      if (map != null) {
        yield map;
      }
    }
  }

  Map<String, dynamic>? _asStringDynamicMap(Object? raw) {
    if (raw is Map) {
      return raw.map((key, value) => MapEntry(key.toString(), value));
    }
    return null;
  }

  List<String> _extractTagValues(
    Map<String, dynamic>? data,
    Map<String, dynamic>? comicItemMap,
  ) {
    for (final map in _candidateMetadataMaps(data, comicItemMap)) {
      for (final key in const [
        'tagList',
        'tags',
        'metadataTags',
        'categories',
        'category',
        'groups',
        'labels',
        'keywords',
      ]) {
        final tags = _normalizeTagValues(map[key]);
        if (tags.isNotEmpty) {
          return tags;
        }
      }
    }
    return const <String>[];
  }

  List<String> _normalizeTagValues(Object? raw) {
    if (raw is List) {
      return raw
          .map(_tagValueFromEntry)
          .map((entry) => entry.trim())
          .where((entry) => entry.isNotEmpty)
          .toSet()
          .toList(growable: false);
    }
    if (raw is Map) {
      return raw.values
          .expand(_normalizeTagValues)
          .map((entry) => entry.trim())
          .where((entry) => entry.isNotEmpty)
          .toSet()
          .toList(growable: false);
    }
    if (raw is String) {
      final normalized = raw.trim();
      if (normalized.isEmpty) {
        return const <String>[];
      }
      if (normalized.startsWith('[') && normalized.endsWith(']')) {
        final decoded = _decodeJsonMap('{"tags":$normalized}')?['tags'];
        if (decoded != null) {
          return _normalizeTagValues(decoded);
        }
      }
      if (normalized.startsWith('{') && normalized.endsWith('}')) {
        final decoded = _decodeJsonMap(normalized);
        if (decoded != null) {
          return _normalizeTagValues(decoded);
        }
      }
      return normalized
          .split(RegExp(r'\s*[,，]\s*'))
          .map((entry) => entry.trim())
          .where((entry) => entry.isNotEmpty)
          .toSet()
          .toList(growable: false);
    }
    final single = raw?.toString().trim() ?? '';
    if (single.isEmpty) {
      return const <String>[];
    }
    return <String>[single];
  }

  String _tagValueFromEntry(Object? raw) {
    if (raw == null) {
      return '';
    }
    if (raw is Map) {
      final mapped = raw.map((key, value) => MapEntry(key.toString(), value));
      return _firstNonEmptyValue([
        mapped['tag']?.toString(),
        mapped['name']?.toString(),
        mapped['title']?.toString(),
        mapped['value']?.toString(),
      ]);
    }
    return raw.toString().trim();
  }

  List<String> _extractEpisodeTitles(
    Map<String, dynamic>? data,
    Map<String, dynamic>? comicItemMap,
  ) {
    for (final map in _candidateMetadataMaps(data, comicItemMap)) {
      for (final key in const [
        'chapters',
        'eps',
        'episodes',
        'episodeList',
        'chapterList',
        'epList',
        'epNames',
      ]) {
        final titles = _normalizeEpisodeTitles(map[key]);
        if (titles.isNotEmpty) {
          return titles;
        }
      }
    }
    return const <String>[];
  }

  List<String> _normalizeEpisodeTitles(Object? raw) {
    if (raw is List) {
      return raw
          .map((entry) => _episodeTitleFromValue(entry))
          .where((entry) => entry.isNotEmpty)
          .toList(growable: false);
    }
    if (raw is Map) {
      final entries = raw.entries.toList()
        ..sort((a, b) =>
            (int.tryParse(a.key.toString()) ?? 0).compareTo(
              int.tryParse(b.key.toString()) ?? 0,
            ));
      return entries
          .map((entry) => _episodeTitleFromValue(entry.value))
          .where((entry) => entry.isNotEmpty)
          .toList(growable: false);
    }
    final single = _episodeTitleFromValue(raw);
    return single.isEmpty ? const <String>[] : <String>[single];
  }

  String _episodeTitleFromValue(Object? raw) {
    if (raw == null) {
      return '';
    }
    if (raw is String) {
      return raw.trim();
    }
    if (raw is Map) {
      final mapped = raw.map((key, value) => MapEntry(key.toString(), value));
      return _firstNonEmptyValue([
        mapped['title']?.toString(),
        mapped['name']?.toString(),
        mapped['chapter']?.toString(),
        mapped['epName']?.toString(),
        mapped['shortTitle']?.toString(),
        mapped['value']?.toString(),
      ]);
    }
    return raw.toString().trim();
  }

  List<ServerResourceEpisodeSummary> _applyEpisodeTitles(
    List<ServerResourceEpisodeSummary> episodes,
    List<String> titles,
  ) {
    if (episodes.isEmpty || titles.isEmpty) {
      return episodes;
    }
    return [
      for (var i = 0; i < episodes.length; i++)
        ServerResourceEpisodeSummary(
          index: episodes[i].index,
          title: i < titles.length && titles[i].trim().isNotEmpty
              ? titles[i].trim()
              : episodes[i].title,
          path: episodes[i].path,
          imageCount: episodes[i].imageCount,
          totalBytes: episodes[i].totalBytes,
          coverPath: episodes[i].coverPath,
          imagePaths: episodes[i].imagePaths,
          imageSizes: episodes[i].imageSizes,
        ),
    ];
  }

  String _firstNonEmptyValue(Iterable<String?> values) {
    for (final value in values) {
      final normalized = value?.trim() ?? '';
      if (normalized.isNotEmpty) {
        return normalized;
      }
    }
    return '';
  }

  String _inferSourceDisplayName(String id, Map<String, dynamic>? data) {
    final sourceKey = (data?['sourceKey']?.toString() ?? '').trim().toLowerCase();
    if (sourceKey == 'copy_manga') return '拷贝漫画';
    if (sourceKey == 'komiic') return 'Komiic';
    if (sourceKey == 'jm') return '禁漫';
    if (sourceKey == 'hitomi') return 'Hitomi';
    if (sourceKey == 'nhentai') return 'NHentai';
    if (sourceKey == 'htmanga') return '绅士漫画';
    if (sourceKey == 'ehentai') return 'E-Hentai';
    if (sourceKey == 'picacg') return '哔咔';

    final normalizedId = id.trim().toLowerCase();
    if (normalizedId.startsWith('jm')) return '禁漫';
    if (normalizedId.startsWith('hitomi')) return 'Hitomi';
    if (normalizedId.startsWith('nhentai')) return 'NHentai';
    if (normalizedId.startsWith('ht')) return '绅士漫画';
    if (normalizedId.contains('-')) {
      final prefix = normalizedId.split('-').first;
      if (prefix == 'copy_manga') return '拷贝漫画';
      if (prefix == 'komiic') return 'Komiic';
    }
    if (RegExp(r'^[0-9a-f]{24}$').hasMatch(normalizedId)) return '哔咔';
    if (RegExp(r'^\d+$').hasMatch(normalizedId)) return 'E-Hentai';
    return '';
  }

  Future<ServerResourceEpisodeSummary?> _buildEpisodeSummary({
    required int index,
    required String title,
    required Directory directory,
    required List<File> images,
  }) async {
    if (images.isEmpty) {
      return null;
    }

    return ServerResourceEpisodeSummary(
      index: index,
      title: title,
      path: directory.path,
      imageCount: images.length,
      totalBytes: await _calculateTotalBytes(images),
      coverPath: _resolveEpisodeCoverPath(directory, images),
      imagePaths: images.map((e) => e.path).toList(growable: false),
      imageSizes: images.map(_readImageSize).toList(growable: false),
    );
  }

  ServerResourceImageSize? _readImageSize(File file) {
    try {
      final bytes = file.openSync(mode: FileMode.read);
      try {
        final length = bytes.lengthSync();
        final headerLength = length < 512 ? length : 512;
        final header = bytes.readSync(headerLength);
        return _readPngSize(header) ??
            _readJpegSize(file) ??
            _readWebpSize(header);
      } finally {
        bytes.closeSync();
      }
    } catch (_) {
      return null;
    }
  }

  ServerResourceImageSize? _readPngSize(List<int> bytes) {
    if (bytes.length < 24 ||
        bytes[0] != 0x89 ||
        bytes[1] != 0x50 ||
        bytes[2] != 0x4E ||
        bytes[3] != 0x47) {
      return null;
    }
    final width = _readUint32BigEndian(bytes, 16);
    final height = _readUint32BigEndian(bytes, 20);
    return width > 0 && height > 0
        ? ServerResourceImageSize(width: width, height: height)
        : null;
  }

  ServerResourceImageSize? _readJpegSize(File file) {
    final raf = file.openSync(mode: FileMode.read);
    try {
      if (raf.lengthSync() < 4 || raf.readByteSync() != 0xFF || raf.readByteSync() != 0xD8) {
        return null;
      }
      while (raf.positionSync() < raf.lengthSync()) {
        var markerPrefix = raf.readByteSync();
        while (markerPrefix != 0xFF && raf.positionSync() < raf.lengthSync()) {
          markerPrefix = raf.readByteSync();
        }
        var marker = raf.readByteSync();
        while (marker == 0xFF && raf.positionSync() < raf.lengthSync()) {
          marker = raf.readByteSync();
        }
        if (marker == 0xD9 || marker == 0xDA) {
          return null;
        }
        final lengthBytes = raf.readSync(2);
        if (lengthBytes.length < 2) {
          return null;
        }
        final segmentLength = _readUint16BigEndian(lengthBytes, 0);
        if (segmentLength < 2) {
          return null;
        }
        final isSizeMarker = (marker >= 0xC0 && marker <= 0xCF) &&
            marker != 0xC4 &&
            marker != 0xC8 &&
            marker != 0xCC;
        if (isSizeMarker) {
          final segment = raf.readSync(segmentLength - 2);
          if (segment.length < 5) {
            return null;
          }
          final height = _readUint16BigEndian(segment, 1);
          final width = _readUint16BigEndian(segment, 3);
          return width > 0 && height > 0
              ? ServerResourceImageSize(width: width, height: height)
              : null;
        }
        raf.setPositionSync(raf.positionSync() + segmentLength - 2);
      }
    } catch (_) {
      return null;
    } finally {
      raf.closeSync();
    }
    return null;
  }

  ServerResourceImageSize? _readWebpSize(List<int> bytes) {
    if (bytes.length < 30 ||
        _ascii(bytes, 0, 4) != 'RIFF' ||
        _ascii(bytes, 8, 4) != 'WEBP') {
      return null;
    }
    final chunk = _ascii(bytes, 12, 4);
    if (chunk == 'VP8X' && bytes.length >= 30) {
      final width = 1 + _readUint24LittleEndian(bytes, 24);
      final height = 1 + _readUint24LittleEndian(bytes, 27);
      return ServerResourceImageSize(width: width, height: height);
    }
    if (chunk == 'VP8 ' && bytes.length >= 30) {
      final width = _readUint16LittleEndian(bytes, 26) & 0x3FFF;
      final height = _readUint16LittleEndian(bytes, 28) & 0x3FFF;
      return width > 0 && height > 0
          ? ServerResourceImageSize(width: width, height: height)
          : null;
    }
    if (chunk == 'VP8L' && bytes.length >= 25) {
      final b0 = bytes[21];
      final b1 = bytes[22];
      final b2 = bytes[23];
      final b3 = bytes[24];
      final width = 1 + (((b1 & 0x3F) << 8) | b0);
      final height = 1 + ((b3 << 6) | (b2 >> 2) | ((b1 & 0xC0) << 6));
      return ServerResourceImageSize(width: width, height: height);
    }
    return null;
  }

  int _readUint16BigEndian(List<int> bytes, int offset) =>
      (bytes[offset] << 8) | bytes[offset + 1];

  int _readUint32BigEndian(List<int> bytes, int offset) =>
      (bytes[offset] << 24) |
      (bytes[offset + 1] << 16) |
      (bytes[offset + 2] << 8) |
      bytes[offset + 3];

  int _readUint16LittleEndian(List<int> bytes, int offset) =>
      bytes[offset] | (bytes[offset + 1] << 8);

  int _readUint24LittleEndian(List<int> bytes, int offset) =>
      bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16);

  String _ascii(List<int> bytes, int offset, int length) =>
      String.fromCharCodes(bytes.skip(offset).take(length));

  String _extractCoverPath(
    Map<String, dynamic>? data,
    Map<String, dynamic>? comicItemMap,
    DownloadedItem? parsedItem,
  ) {
    final parsedCover = parsedItem?.localCoverPath?.trim() ?? '';
    if (parsedCover.isNotEmpty && File(parsedCover).existsSync()) {
      return parsedCover;
    }

    for (final map in _candidateMetadataMaps(data, comicItemMap)) {
      for (final key in const ['coverPath', 'cover', 'localCoverPath']) {
        final raw = map[key]?.toString().trim() ?? '';
        if (raw.isEmpty) {
          continue;
        }
        final file = File(raw);
        if (file.existsSync()) {
          return file.path;
        }
      }
    }
    return '';
  }

  String _resolveItemCoverPath(
    String? metadataCoverPath,
    Directory directory,
    List<ServerResourceEpisodeSummary> episodes,
  ) {
    final normalizedMetadataPath = metadataCoverPath?.trim() ?? '';
    if (normalizedMetadataPath.isNotEmpty &&
        File(normalizedMetadataPath).existsSync()) {
      return normalizedMetadataPath;
    }

    final coverFile = _findCoverLikeImage(directory);
    if (coverFile != null) {
      return coverFile.path;
    }

    for (final episode in episodes) {
      final coverPath = episode.coverPath?.trim() ?? '';
      if (coverPath.isNotEmpty) {
        return coverPath;
      }
    }
    return '';
  }

  String _resolveEpisodeCoverPath(Directory directory, List<File> images) {
    final coverFile = _findCoverLikeImage(directory);
    if (coverFile != null) {
      return coverFile.path;
    }
    return images.first.path;
  }

  File? _findCoverLikeImage(Directory directory) {
    for (final entity in _safeList(directory)) {
      if (entity is! File) {
        continue;
      }
      if (!_isImageFile(entity.path) || _isInServerTrash(entity.path)) {
        continue;
      }
      if (_isCoverLikeFile(entity.path)) {
        return entity;
      }
    }
    return null;
  }

  Future<int> _calculateTotalBytes(List<File> files) async {
    var totalBytes = 0;
    for (final file in files) {
      try {
        totalBytes += await file.length();
      } catch (_) {}
    }
    return totalBytes;
  }

  Future<DateTime> _directoryUpdatedAt(Directory directory) async {
    try {
      return (await directory.stat()).modified;
    } catch (_) {
      return DateTime.fromMillisecondsSinceEpoch(0);
    }
  }

  Future<List<Directory>> _listDirectories(Directory directory) async {
    final results = <Directory>[];
    await for (final entity in directory.list(recursive: false, followLinks: false)) {
      if (entity is Directory && _basename(entity.path) != _serverTrashDirectoryName) {
        results.add(entity);
      }
    }
    results.sort(_compareEntityPath);
    return results;
  }

  Future<List<File>> _listImageFiles(
    Directory directory, {
    required bool recursive,
  }) async {
    final results = <File>[];
    await for (final entity in directory.list(
      recursive: recursive,
      followLinks: false,
    )) {
      if (entity is! File) {
        continue;
      }
      if (_isInServerTrash(entity.path)) {
        continue;
      }
      if (!_isImageFile(entity.path)) {
        continue;
      }
      results.add(entity);
    }
    results.sort(_compareEntityPath);
    return results;
  }

  List<File> _listDirectVisibleImages(Directory directory) {
    final results = <File>[];
    for (final entity in _safeList(directory)) {
      if (entity is! File) {
        continue;
      }
      if (!_isImageFile(entity.path)) {
        continue;
      }
      results.add(entity);
    }
    results.sort(_compareEntityPath);
    final visibleFiles = results.where((file) => !_isCoverLikeFile(file.path)).toList();
    return visibleFiles.isNotEmpty ? visibleFiles : results;
  }

  List<Directory> _collectLeafAlbumDirectories(Directory root) {
    final results = <Directory>[];

    bool visit(Directory directory) {
      final children = _safeList(directory);
      final hasImages = children.any(_isVisibleImageFile);
      var hasAlbumDescendant = false;
      for (final child in children.whereType<Directory>()) {
        if (_basename(child.path) == _serverTrashDirectoryName) {
          continue;
        }
        if (visit(child)) {
          hasAlbumDescendant = true;
        }
      }
      if (hasImages && !hasAlbumDescendant) {
        results.add(directory);
        return true;
      }
      return hasImages || hasAlbumDescendant;
    }

    visit(root);
    results.sort(_compareEntityPath);
    return results;
  }

  List<FileSystemEntity> _safeList(Directory directory) {
    try {
      return directory.listSync(recursive: false, followLinks: false);
    } catch (_) {
      return const <FileSystemEntity>[];
    }
  }

  bool _isVisibleImageFile(FileSystemEntity entity) {
    return entity is File &&
        !_isInServerTrash(entity.path) &&
        _isImageFile(entity.path) &&
        !_basename(entity.path).startsWith('.');
  }

  bool _isInServerTrash(String path) {
    final normalized = path.replaceAll('\\', '/');
    return normalized
        .split('/')
        .any((segment) => segment == _serverTrashDirectoryName);
  }

  bool _isCoverLikeFile(String path) {
    final name = _basename(path).toLowerCase();
    return name == 'cover.jpg' ||
        name == 'cover.jpeg' ||
        name == 'cover.png' ||
        name == 'cover.webp';
  }

  String _basename(String path) {
    final normalized = path.replaceAll('\\', '/');
    final parts = normalized.split('/').where((entry) => entry.isNotEmpty).toList();
    return parts.isEmpty ? normalized : parts.last;
  }

  String _buildItemId(String rootId, String path) {
    final raw = utf8.encode('$rootId::$path');
    return base64Url.encode(raw).replaceAll('=', '');
  }

  bool _isImageFile(String path) {
    final lower = path.toLowerCase();
    return lower.endsWith('.jpg') ||
        lower.endsWith('.jpeg') ||
        lower.endsWith('.png') ||
        lower.endsWith('.webp') ||
        lower.endsWith('.gif') ||
        lower.endsWith('.bmp');
  }

  String _directoryTitle(Directory directory) {
    final normalized = directory.path.replaceAll('\\', '/');
    final parts = normalized.split('/').where((e) => e.isNotEmpty).toList();
    return parts.isEmpty ? directory.path : parts.last;
  }

  int _compareEntityPath(FileSystemEntity a, FileSystemEntity b) {
    return _naturalCompare(_normalizePath(a.path), _normalizePath(b.path));
  }

  String _normalizePath(String path) {
    return path.replaceAll('\\', '/').toLowerCase();
  }

  int _naturalCompare(String a, String b) {
    final aTokens = _naturalTokens(a);
    final bTokens = _naturalTokens(b);
    final length = aTokens.length < bTokens.length ? aTokens.length : bTokens.length;
    for (var i = 0; i < length; i++) {
      final left = aTokens[i];
      final right = bTokens[i];
      if (left is int && right is int) {
        final compare = left.compareTo(right);
        if (compare != 0) {
          return compare;
        }
        continue;
      }
      final compare = left.toString().compareTo(right.toString());
      if (compare != 0) {
        return compare;
      }
    }
    return aTokens.length.compareTo(bTokens.length);
  }

  List<Object> _naturalTokens(String value) {
    final matches = RegExp(r'(\d+|\D+)').allMatches(value);
    return matches.map((match) {
      final part = match.group(0)!;
      final number = int.tryParse(part);
      return number ?? part;
    }).toList(growable: false);
  }
}
