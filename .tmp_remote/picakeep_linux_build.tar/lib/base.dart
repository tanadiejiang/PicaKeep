// ignore_for_file: depend_on_referenced_packages

import 'dart:convert';
import 'dart:io';

import 'foundation/app.dart';
import 'foundation/app_runtime_mode.dart';
import 'foundation/local_data_source.dart';
import 'foundation/local_library_settings.dart';
import 'foundation/log.dart';
import 'foundation/history.dart';
import 'foundation/local_favorites.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'foundation/def.dart';
import 'foundation/download.dart';
export 'foundation/def.dart';

String get pathSep => Platform.pathSeparator;

var downloadManager = DownloadManager();

class Appdata {
  List<String> searchHistory = [];
  Set<String> favoriteTags = {};

  var history = HistoryManager();

  List<String> settings = [
    "1", //0
    "dd", //1
    "1", //2
    "0", //3
    "1", //4
    "1", //5
    "1", //6
    "1", //7
    "0", //8
    "1", //9
    "0", //10
    "0", //11
    "0", //12
    "0", //13
    "1", //14
    "1", //15
    "0", //16
    "0", //17
    "0", //18
    "0", //19
    "0", //20
    "111111", //21
    "", //22
    "0", //23
    "1111111111", //24
    "0", //25
    "00", //26
    "0", //27
    "2", //28
    "0", //29
    "1", //30
    "https://www.wnacg.com", //31
    "0", //32
    "5", //33
    "1000", //34
    "500", //35
    "1", //36
    "0", //37
    "0", //38
    "0", //39
    "25", //40
    "0", //41
    "0", //42
    "1", //43
    "0,1.0", //44
    "", //45
    "0", //46
    "0", //47
    "https://nhentai.net", //48
    "1", //49
    "", //50
    "", //51
    "0", //52
    "0", //53
    "0", //54
    "1", //55
    "https://18comic.vip", //56
    "1", //57
    "0", //58
    "012345678", //59
    "0", //60
    "0", //61
    "10000", //62
    "0", //63
    "0", //64
    "0", //65
    "0", //66
    "picacg,ehentai,jm,htmanga,nhentai", //67
    "picacg,ehentai,jm,htmanga,nhentai", //68
    "0", //69
    "0", //70
    "1", // 71
    "1", //72
    "0", //73
    "1.0", //74
    "0", //75
    "0", //76
    "picacg,Eh主页,Eh热门,禁漫主页,禁漫最新,hitomi,绅士漫画,nhentai", //77
    "0", //78
    "6", //79
    "1", //80
    "0", //81
    "111111", //82
    "1", //83
    "0", //84
    "www.cdntwice.org,www.cdnsha.org,www.cdnaspa.cc,www.cdnntr.cc", //85
    "https://cdn-msp.jmapiproxy3.cc", //86
    "gold-usergeneratedcontent.net", //87
    "0", //88
    "2.0.11", //89
    "", //90 原应用下载目录
    "[]", //91 本地漫画路径列表
    "0", //92 本地图集图片排序
    "time_desc", //93 本地图集列表排序
    "1", //94 本地图集页仅显示图集
    "0", //95 本地详情页相关推荐模式
    "0", //96 无论有无文件都按下载数据库显示
    "client", //97 运行模式
    "", //98 客户端服务端地址
    "mdns", //99 局域网发现方式
    "9527", //100 服务端后台端口
    "0", //101 安卓 Root 浏览模式
    "0", //102 安卓 Shizuku 浏览模式
    "local", //103 已下载页来源视图
    "local", //104 资源库页来源视图
    "trash", //105 删除行为
    '["service_info","local_files","app_capabilities","trash"]', //106 外显工具顺序
    '["service_info","local_files","app_capabilities","trash"]', //107 外显工具显示
    '[]', //108 压缩包默认密码列表
    '1', //109 压缩包自动解密开关
    '32', //110 压缩包阅读缓存上限 MB
    '0', //111 压缩包章节使用序号
  ];

  List<String> implicitData = [
    "1;;",
    "0",
    "0",
    webUA,
  ];

  void writeImplicitData() async {
    var s = await SharedPreferences.getInstance();
    await s.setStringList("implicitData", implicitData);
  }

  void readImplicitData() async {
    var s = await SharedPreferences.getInstance();
    var data = s.getStringList("implicitData");
    if (data == null) {
      writeImplicitData();
      return;
    }
    for (int i = 0; i < data.length && i < implicitData.length; i++) {
      implicitData[i] = data[i];
    }
  }

  List<String> blockingKeyword = [];

  List<String> firstUse = [
    "1",
    "1",
    "1",
    "0",
    "1",
  ];

  int getSearchMode() {
    var modes = ["dd", "da", "ld", "vd"];
    return modes.indexOf(settings[1]);
  }

  void setSearchMode(int mode) async {
    var modes = ["dd", "da", "ld", "vd"];
    settings[1] = modes[mode];
    var s = await SharedPreferences.getInstance();
    await s.setStringList("settings", settings);
  }

  Future<void> readSettings(SharedPreferences s) async {
    var settingsFile = File("${App.dataPath}/settings");
    List<String> st;
    if (settingsFile.existsSync()) {
      var json = jsonDecode(await settingsFile.readAsString());
      if (json is List) {
        st = List.from(json);
      } else {
        st = [];
      }
    } else {
      st = s.getStringList("settings") ?? [];
    }
    for (int i = 0; i < st.length && i < settings.length; i++) {
      settings[i] = st[i];
    }
    if (settings[26].length < 2) {
      settings[26] += "0";
    }
    settings[managedDataSourceModeSettingIndex] =
        normalizeManagedDataSourceMode(
            settings[managedDataSourceModeSettingIndex]);
    settings[originalDownloadDirSettingIndex] =
        settings[originalDownloadDirSettingIndex].trim();
    settings[localComicPathsSettingIndex] = encodeLocalComicPathList(
      decodeLocalComicPathList(settings[localComicPathsSettingIndex]),
    );
    settings[localAlbumImageSortSettingIndex] =
        normalizeLocalAlbumImageSort(settings[localAlbumImageSortSettingIndex]);
    settings[localLibraryListSortSettingIndex] = normalizeLocalLibraryListSort(
        settings[localLibraryListSortSettingIndex]);
    if (settings[localLibraryAlbumOnlySettingIndex] != "0") {
      settings[localLibraryAlbumOnlySettingIndex] = "1";
    }
    settings[localDetailRecommendationSettingIndex] =
        normalizeLocalDetailRecommendationMode(
            settings[localDetailRecommendationSettingIndex]);
    settings[localLibraryShowAllDatabaseRecordsSettingIndex] =
        normalizeLocalLibraryShowAllDatabaseRecords(
            settings[localLibraryShowAllDatabaseRecordsSettingIndex]);
    settings[downloadedLibraryViewSettingIndex] =
        normalizeDownloadedLibraryView(
            settings[downloadedLibraryViewSettingIndex]);
    settings[localLibraryViewSettingIndex] =
        normalizeLocalLibraryView(settings[localLibraryViewSettingIndex]);
    settings[appRuntimeModeSettingIndex] =
        normalizeAppRuntimeMode(settings[appRuntimeModeSettingIndex]);
    settings[remoteServerAddressSettingIndex] =
        settings[remoteServerAddressSettingIndex].trim();
    settings[serviceDiscoveryModeSettingIndex] = normalizeServiceDiscoveryMode(
        settings[serviceDiscoveryModeSettingIndex]);
    settings[serviceAdminPortSettingIndex] =
        normalizeServiceAdminPortValue(settings[serviceAdminPortSettingIndex]);
    settings[androidRootModeSettingIndex] =
        normalizeAndroidRootMode(settings[androidRootModeSettingIndex]);
    settings[androidShizukuModeSettingIndex] =
        normalizeAndroidShizukuMode(settings[androidShizukuModeSettingIndex]);
    settings[deleteBehaviorSettingIndex] =
        normalizeDeleteBehavior(settings[deleteBehaviorSettingIndex]);
    settings[externalToolOrderSettingIndex] = normalizeExternalToolOrderSetting(
        settings[externalToolOrderSettingIndex]);
    settings[externalToolVisibilitySettingIndex] =
        normalizeExternalToolVisibilitySetting(
            settings[externalToolVisibilitySettingIndex]);
    setManagedDataSourceMode(settings[managedDataSourceModeSettingIndex]);
  }

  Future<void> updateSettings([bool syncData = true]) async {
    var settingsFile = File("${App.dataPath}/settings");
    await settingsFile.writeAsString(jsonEncode(settings));
    if (syncData) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList("settings", settings);
  }

  void writeFirstUse() async {
    var s = await SharedPreferences.getInstance();
    await s.setStringList("firstUse", firstUse);
  }

  void writeHistory() async {
    var s = await SharedPreferences.getInstance();
    await s.setStringList("search", searchHistory);
    await s.setStringList("favoriteTags", favoriteTags.toList());
  }

  Future<void> writeData([bool sync = true]) async {
    await updateSettings();
  }

  Future<bool> readEssentialData() async {
    var s = await SharedPreferences.getInstance();
    try {
      AppStartupTrace.log('appdata.readEssentialData.start');
      await readSettings(s);
      if (s.getStringList("firstUse") != null) {
        var st = s.getStringList("firstUse")!;
        for (int i = 0; i < st.length; i++) {
          firstUse[i] = st[i];
        }
      }
      AppStartupTrace.log('appdata.readEssentialData.done');
      return firstUse[3] == "1";
    } catch (e) {
      AppStartupTrace.log('appdata.readEssentialData.failed: $e');
      return false;
    }
  }

  Future<void> readDeferredData() async {
    var s = await SharedPreferences.getInstance();
    try {
      AppStartupTrace.log('appdata.readDeferredData.start');
      searchHistory = s.getStringList("search") ?? [];
      favoriteTags = (s.getStringList("favoriteTags") ?? []).toSet();
      blockingKeyword = s.getStringList("blockingKeyword") ?? [];
      readImplicitData();
      AppStartupTrace.log('appdata.readDeferredData.done');
    } catch (e) {
      AppStartupTrace.log('appdata.readDeferredData.failed: $e');
    }
  }

  Future<bool> readData() async {
    try {
      final result = await readEssentialData();
      await readDeferredData();
      return result;
    } catch (e) {
      return false;
    }
  }

  Map<String, dynamic> toJson() => {
        "settings": settings,
        "firstUse": firstUse,
        "blockingKeywords": blockingKeyword,
        "favoriteTags": favoriteTags.toList(),
      };

  bool readDataFromJson(Map<String, dynamic> json) {
    try {
      var newSettings = List<String>.from(json["settings"]);
      var downloadPath = settings[22];
      var authRequired = settings[13];
      for (var i = 0; i < settings.length && i < newSettings.length; i++) {
        settings[i] = newSettings[i];
      }
      settings[managedDataSourceModeSettingIndex] =
          normalizeManagedDataSourceMode(
              settings[managedDataSourceModeSettingIndex]);
      settings[originalDownloadDirSettingIndex] = downloadPath;
      settings[localComicPathsSettingIndex] = encodeLocalComicPathList(
        decodeLocalComicPathList(settings[localComicPathsSettingIndex]),
      );
      settings[localAlbumImageSortSettingIndex] = normalizeLocalAlbumImageSort(
          settings[localAlbumImageSortSettingIndex]);
      settings[localLibraryListSortSettingIndex] =
          normalizeLocalLibraryListSort(
              settings[localLibraryListSortSettingIndex]);
      settings[localDetailRecommendationSettingIndex] =
          normalizeLocalDetailRecommendationMode(
              settings[localDetailRecommendationSettingIndex]);
      settings[localLibraryShowAllDatabaseRecordsSettingIndex] =
          normalizeLocalLibraryShowAllDatabaseRecords(
              settings[localLibraryShowAllDatabaseRecordsSettingIndex]);
      settings[downloadedLibraryViewSettingIndex] =
          normalizeDownloadedLibraryView(
              settings[downloadedLibraryViewSettingIndex]);
      settings[localLibraryViewSettingIndex] =
          normalizeLocalLibraryView(settings[localLibraryViewSettingIndex]);
      settings[deleteBehaviorSettingIndex] =
          normalizeDeleteBehavior(settings[deleteBehaviorSettingIndex]);
      settings[externalToolOrderSettingIndex] =
          normalizeExternalToolOrderSetting(
              settings[externalToolOrderSettingIndex]);
      settings[externalToolVisibilitySettingIndex] =
          normalizeExternalToolVisibilitySetting(
              settings[externalToolVisibilitySettingIndex]);
      setManagedDataSourceMode(settings[managedDataSourceModeSettingIndex]);
      settings[22] = downloadPath;
      settings[13] = authRequired;
      var newFirstUse = List<String>.from(json["firstUse"]);
      for (var i = 0; i < firstUse.length && i < newFirstUse.length; i++) {
        firstUse[i] = newFirstUse[i];
      }
      if (json["history"] != null) {
        history.readDataFromJson(json["history"]);
      }
      blockingKeyword = Set<String>.from(
              ((json["blockingKeywords"] ?? []) + blockingKeyword) as List)
          .toList();
      favoriteTags =
          Set.from((json["favoriteTags"] ?? []) + List.from(favoriteTags));
      writeData(false);
      return true;
    } catch (e, s) {
      LogManager.addLog(LogLevel.error, "Appdata.readDataFromJson",
          "error reading appdata$e\n$s");
      readData();
      return false;
    }
  }

  final appSettings = _Settings();

  ReaderSettings readerSettings = ReaderSettings();

  bool read(dynamic key) => true;

  void save() {
    writeData();
  }
}

var appdata = Appdata();

class ReaderSettings {
  int readerType = 0;
  int readerDirection = 0;
  int readingDirection = 0;
  double pageTurningInterval = 0.0;
  int preload = 0;
  String readingBounds = '';
}

Future<void> eraseCache(
    {List<String>? types, bool onlyExpired = false}) async {}

Future<void> clearAppdata() async {
  var s = await SharedPreferences.getInstance();
  await s.clear();
  var settingsFile = File("${App.dataPath}/settings");
  if (await settingsFile.exists()) {
    await settingsFile.delete();
  }
  appdata.history.clearHistory();
  appdata = Appdata();
  await appdata.readData();
  await eraseCache();
  await LocalFavoritesManager().clearAll();
}

class _Settings {
  List<String> get _settings => appdata.settings;

  int get theme => int.parse(_settings[27]);

  set theme(int value) {
    appdata.settings[27] = value.toString();
  }

  int get darkMode => int.parse(appdata.settings[32]);

  set darkMode(int value) {
    appdata.settings[32] = value.toString();
  }

  int get comicTileDisplayType =>
      int.parse(appdata.settings[44].split(',').first);

  set comicTileDisplayType(int v) {
    var values = appdata.settings[44].split(',');
    if (values.length != 2) {
      values = ['0', '1.0'];
    }
    values[0] = v.toString();
    appdata.settings[44] = values.join(',');
  }

  int get comicsListDisplayType => int.parse(appdata.settings[25]);

  set comicsListDisplayType(int value) {
    appdata.settings[25] = value.toString();
  }

  String get initialSearchTarget => appdata.settings[63];

  set initialSearchTarget(String value) {
    appdata.settings[63] = value;
  }

  bool get reduceBrightnessInDarkMode => appdata.settings[18] == "1";

  set reduceBrightnessInDarkMode(bool value) {
    appdata.settings[18] = value ? "1" : "0";
  }

  bool get showPageInfoInReader => appdata.settings[57] == "1";

  set showPageInfoInReader(bool value) {
    appdata.settings[57] = value ? "1" : "0";
  }

  bool get showButtonsInReader => appdata.settings[4] == "1";

  set showButtonsInReader(bool value) {
    appdata.settings[4] = value ? "1" : "0";
  }

  bool get flipPageWithClick => appdata.settings[0] == "1";

  set flipPageWithClick(bool value) {
    appdata.settings[0] = value ? "1" : "0";
  }

  bool get useDarkBackground => appdata.settings[81] == "1";

  set useDarkBackground(bool value) {
    appdata.settings[81] = value ? "1" : "0";
  }

  bool get fullyHideBlockedWorks => appdata.settings[83] == "1";

  set fullyHideBlockedWorks(bool value) {
    appdata.settings[83] = value ? "1" : "0";
  }

  int get cacheLimit => int.tryParse(appdata.settings[35]) ?? 500;

  set cacheLimit(int value) {
    appdata.settings[35] = value.toString();
  }
}
